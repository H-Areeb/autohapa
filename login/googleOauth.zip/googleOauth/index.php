
<?php
require_once 'google-api-php-client/src/Google/autoload.php';
//include "../configfile.php"; // for systems credentials
session_start();
$location       = "localhost";
$databasename   = "judaic_h223730";
$databaseuser   = "judaic_user";
$databasepasswd = "Logoinn345@";
$database_name  = "judaic_h223730";
$db_name        = "judaic_h223730";

//$secure    = "http://www.judaicconnection.com/";
$secure    = "http://judaic.logoinn.me/jc/"; //test server path


$client = new Google_Client();
$client->setAuthConfig('client_secret.json');

$client->addScope(array("https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile"
));
//$client->addScope("https://www.googleapis.com/auth/userinfo.email");

if(isset($_GET['code'])){
     $client->authenticate($_GET['code']);
     $_SESSION['access_token'] = $client->getAccessToken();
    $arr =     $client->getAccessToken();
 
    // make an HTTP request
    
    $result = file_get_contents('https://www.googleapis.com/oauth2/v1/userinfo?access_token='.$arr['access_token'],false);
     $user_detail = json_decode($result);
   //  var_dump($user_detail);
    if(isset($user_detail->id)){
     //   echo($user_detail->id);
    
    
    // check user email credential from database 
    
    
    
    
    
    
    /* copy from sysmain2.php for login and set cookie logic
    * copy start
    */
    
    $db_conn = mysql_connect("$location", "$databaseuser", "$databasepasswd");


    
      mysql_select_db($databasename, $db_conn);
    
    
    /**
     * my code checking is user exists in database
     * start
     * if no then insert into database
     */
     
     
     $check_query = 'select * from customer_table where email_address = "'.$user_detail->email.'";';
     $check_query_exec =  mysql_query($check_query, $db_conn);
     if (mysql_num_rows($check_query_exec) == 0) {
        // create an user_identity table to store external user info
       
        
        $insert_query = 'INSERT INTO customer_table (email_address,customer_username,customer_password)  VALUES ("'.$user_detail->email.'","'.$user_detail->name.'","dummy")';
       
        $insert_query_exec =  mysql_query($insert_query, $db_conn);
     
     
     
     }     
     
     
     
     
     
     
    
    /**
     * my code checking is user exists in database
     * end
     * if no then insert into database
     */
    
    
    
    
      $query ='select * from customer_table where email_address="'.$user_detail->email.'";';
    
  //  var_dump($query);
    
      $result = mysql_query($query, $db_conn) or die(mysql_error());
    
      while ($row = mysql_fetch_array($result)){
    
      $customer_id = $row['customer_id'];
    
      $customer_username = $row['customer_username'];
    
   //   $customer_password = $row['customer_password'];
    
      $email_address = $row['email_address'];
    
    
    
    }
    
    
    
      if (mysql_num_rows($result) >0 ) {
    
    
    
        // if they are in the database register the user information
    
    
    
        $user_name_cart = $customer_username;
    
        setcookie("usernamecart", $user_name_cart);
    
        setcookie("customer_username", $customer_username);
    
        setcookie("email_address", $email_address);
    
        $query_string = htmlentities($_SESSION['query_string']);
         
         
          echo "=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>=>";    
          var_dump($customer_username);
   
         echo "=>";     
        var_dump($_COOKIE);
   
        
      //  header("Location: $nonsecure"."buyfav.php?".urldecode($query_string));
      //header("Location: http://judaic.logoinn.me/jc/buyfav.php?".urldecode($query_string));
    	
    //	header("Location: http://judaic.logoinn.me/jc/favbasket.php?".$query_string);
    //		header("Location: http://judaic.logoinn.me/jc/");
    //	unset($_SESSION['query_string']);
   
      } 
    
    
     /* copy from sysmain2.php for login and set cookie logic
    * copy end
    */
    
    
    
       die("end"); 
        
    }else{
        echo "Error Occur";
    }
    
    
    
    
}
//var_dump($_REQUEST);

if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
    $client->setAccessToken($_SESSION['access_token']);
    $drive = new Google_Service_Drive($client);
    $files = $drive->files->listFiles(array())->getItems();
    echo json_encode($files);
} else {
    $redirect_uri = 'http://judaic.logoinn.me/jc/googleOauth/oauth.php';
    header('Location: ' . filter_var($redirect_uri, FILTER_SANITIZE_URL));
}
echo "final page;";