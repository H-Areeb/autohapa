<html>
	<head>
		<title>Approved AD</title>
	</head>
	<body>
		<table>
			<tr><td>&nbsp;</td></tr>
			<tr><td><img src="http://autohapa.oneviewcrm.com/autohapa/assets/images/logo.png"></td></tr>
			<tr><td>Dear <?php echo e($name); ?>!</td></tr>
            <tr><td>Having this email : <?php echo e($email); ?>!</td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td>Your AD has been Approved Successfully!</td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td><a href="#">Your AD Title  : <?php echo e($adTitle); ?></a></td></tr>
			<tr><td>&nbsp;</td></tr>
            <tr><td>&nbsp;</td></tr>
			<tr><td><a href="#">Your Registration Number : <?php echo e($RegNum); ?></a></td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td>Thanks & Regards,</td></tr>
			<tr><td>AutoHapa Team</td></tr>
	</body>
</html><?php /**PATH C:\xampp\htdocs\autohapa\admin\resources\views/email/approvedEmail.blade.php ENDPATH**/ ?>