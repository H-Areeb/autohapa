<?php $__env->startSection('content'); ?>

<h1>Hello from all ads</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\autohapa\resources\views/includes/admin/ads/all.blade.php ENDPATH**/ ?>