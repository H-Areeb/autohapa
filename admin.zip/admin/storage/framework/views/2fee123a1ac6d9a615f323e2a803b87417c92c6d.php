<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('admin_assets/dist/css/searchCarStyleCode.css')); ?>" />



<section class="content-header">
    <h1>
        Seller Details
        <small></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><a href="<?php echo e(route('Sellers')); ?>">Sellers List</a></li>
    </ol>
</section>

<div class="row">
    <div class="col-xs-4"></div>
    <div class="col-xs-4">
        <?php if(Session::has('success')): ?>

        <div class="alert alert-success alert-dismissible" role="alert" id="success">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo e(Session::get('success')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="col-xs-4"></div>
</div>




<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">

            <div class="box-header">
                        <h1 class="box-title"><?php echo e($sellerads[0]->sellerName); ?></h1> 
                 </div> 
            <!-- /.box-header -->


                <div class="box-body">
                    
                    <ul id="searchCarsList" class="col-lg-8">

                        <?php $__currentLoopData = $sellerads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sellerad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li class="search-page__result">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-4"><a href="<?php echo e(route('show',$sellerad->id)); ?>"><img src="http://localhost/autohapa/assets/<?php echo e($sellerad->image); ?>" alt="" class="img-responsive"></a></div>
                                        <div class="col-lg-8">
                                            <div class="row">
                                                <div class="col-lg-9" style="border-right:1px solid #ccc">
                                                    <h4 class="title text-left"><a href="<?php echo e(route('show',$sellerad->id)); ?>"><?php echo e($sellerad->title); ?></a></h4>
                                                    <!-- <p class="blockquote mt-2 tagss"><?php echo e($sellerad->milage); ?> miles | <?php echo e($sellerad->color); ?> | <?php echo e(substr($sellerad->derivative, 0, 3)); ?> L | <?php echo e($sellerad->Transmission); ?> | <?php echo e($sellerad->FuelType); ?> </p>
                                                    <p style="font-size:12px;"><?php echo e(substr($sellerad->Detail, 0, 50)); ?>.</p>-->
                                                    <br>
                                                    <?php if($sellerad->Approved_id == '1'): ?>
                                                        <span class="label label-success" style="font-size:18px;">Approved</span> 
                                                    <?php else: ?>
                                                        <span class="label label-danger" style="font-size:18px;">Not Approved</span> 
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-lg-3"><span class="badge price-badge w-100" style="font-size:18px;">$<?php echo e($sellerad->price); ?></span></div>
                                            </div>
                                        </div>
                                        <!-- <div id="image_preview" class="row mt-2 ml-5">
                                        <?php $__currentLoopData = $adimg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img id="" src="http://localhost/autohapa/assets/<?php echo e($img->name); ?>" class="img-responsive">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div> -->
                                    </div>
                                </div>
                            </div>
                            <!-- <ul class="car_div_ul">
                                <li><a href="#">Get an insurance quote </a></li>
                                <li><a href="#"> Check its history</a></li>
                            </ul> -->
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                    </ul>

                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\autohapa\admin\resources\views/sellers/SellerDetails.blade.php ENDPATH**/ ?>