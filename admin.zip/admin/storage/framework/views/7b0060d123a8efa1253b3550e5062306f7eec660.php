<?php $__env->startSection('content'); ?>

 <!-- Content Header (Page header) -->
 <section class="content-header">
      <h1>
        All Ads
        <small>advanced tables</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">All Ads</li>
      </ol>
    </section>


            <div class="row">
                      <div class="col-xs-4"></div>
                    <div class="col-xs-4">
                        <?php if(Session::has('success')): ?>
                        
                        <div class="alert alert-success alert-dismissible" role="alert" id="success">
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                      <?php echo e(Session::get('success')); ?>

                          </div>
                        <?php endif; ?>
                      </div>
                          <div class="col-xs-4"></div>
                  </div>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          

          <div class="box">
            <!-- <div class="box-header">
               <h3 class="box-title">Data Table With Full Features</h3> 
            </div> -->
            <!-- /.box-header -->
            <div class="box-body">
              <table id="adsTable" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sr no</th>
                  <th>Title</th>
                  <th>Description</th>
                  <th>Price</th>
                  <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                
               <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <!-- <li>".$ad->carregistrationnumber."<li>"; -->

                   <tr>
                        <td><?php echo e($ad->id); ?></td>
                        <td><?php echo e(str_limit($ad->adtitle, 10)); ?></td>
                        <td><?php echo e(str_limit($ad->adverttext, 50)); ?></td>
                        <td><?php echo e($ad->price); ?></td>
                        <td>
                        <a class="btn btn-info" href="<?php echo e(route('show',$ad->id)); ?>">Show</a>
                        <!-- <a class="btn btn-success" href="<?php echo e(route('approved',$ad->id)); ?>">Approved</a>
                         <a href="#" class="btn btn-danger">delete</a> -->
                        </td>
                </tr>
    
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
               
                </tbody>
                <!-- <tfoot>
                <tr>
                  <th>Rendering engine</th>
                  <th>Browser</th>
                  <th>Platform(s)</th>
                  <th>Engine version</th>
                  <th>CSS grade</th>
                </tr>
                </tfoot> -->
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

    
    <script>    
          jQuery("#success").delay(1000).fadeOut("slow");
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\autohapa\admin\resources\views/ads/all.blade.php ENDPATH**/ ?>