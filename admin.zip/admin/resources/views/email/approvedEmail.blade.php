<html>
	<head>
		<title>Approved AD</title>
	</head>
	<body>
		<table>
			<tr><td>&nbsp;</td></tr>
			<tr><td><img src="http://autohapa.oneviewcrm.com/autohapa/assets/images/logo.png"></td></tr>
			<tr><td>Dear {{ $name }}!</td></tr>
            <tr><td>Having this email : {{ $email }}!</td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td>Your AD has been Approved Successfully!</td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td><a href="#">Your AD Title  : {{ $adTitle }}</a></td></tr>
			<tr><td>&nbsp;</td></tr>
            <tr><td>&nbsp;</td></tr>
			<tr><td><a href="#">Your Registration Number : {{ $RegNum }}</a></td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td>Thanks & Regards,</td></tr>
			<tr><td>AutoHapa Team</td></tr>
	</body>
</html>